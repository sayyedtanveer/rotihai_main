interface Chef {
  id: string;
  name: string;
  description: string;
  image: string;
  rating: string;
  reviewCount: number;
  categoryId: string;
}
